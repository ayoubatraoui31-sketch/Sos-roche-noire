# V3.2.1 — correctifs avant compilation

Ce ZIP n'est PAS un APK : l'environnement de l'assistant n'a ni Flutter ni Android SDK ni Internet.
L'APK se fabrique en 1 clic sur GitHub (voir ci-dessous) ou avec `tool/build_apk_*`.

## Bugs corrigés
1. **Tests cassés** : `directions_service_test.dart` utilisait `DirectionsService.maxWaypoints` (supprimé en 3.2)
   -> erreur de compilation qui faisait échouer TOUT `flutter test`. Réécrit pour le calcul local.
   Les tests de tracé utilisaient le format Google ; `fakes.dart` produit maintenant le format `local:`.
2. **ErrorReporter** : les pannes réseau étaient envoyées comme bugs ; la distinction trace/bug est rétablie
   (les tests existants l'exigent).
3. **Permissions Android manquantes** : `flutter create` ne met aucun `<uses-permission>` dans le manifeste de
   release. Sans correctif, l'APK n'aurait eu ni Internet (la carte OpenStreetMap restait grise), ni GPS, ni caméra.
   Nouveau `tool/patch_android_manifest.dart`, appelé par les scripts et le workflow.
4. `flutter analyze` ne bloque plus la fabrication de l'APK dans les scripts (avertissement seulement).

## Fabriquer app-release.apk
**Option A — GitHub (aucune installation)** : poussez ce dossier sur un dépôt GitHub, onglet Actions >
« Build APK (gratuit) » > Run workflow > téléchargez l'artefact `collecte-casabaia-apk`.
**Option B — PC** : installez Flutter, puis `tool\build_apk_windows.bat` (ou `tool/build_apk_linux_mac.sh`).
L'APK est signé avec la clé de debug : installable directement sur Android (sources inconnues),
pas publiable sur Google Play (il faudrait votre propre keystore).

## Limites à connaître (conception 3.2)
- Les distances sont des **lignes droites** (formule GPS), vitesse fixe 25 km/h : le tracé bleu traverse les
  bâtiments, et km / litres / MAD « économisés » sont des estimations, pas des distances routières.
- Les tuiles OpenStreetMap exigent Internet (pas de carte hors ligne) et leur politique d'usage limite
  les gros volumes : pour une flotte, prévoir un fournisseur de tuiles dédié.
- Plus aucun rapport d'erreur distant : les erreurs ne vont que dans les logs de l'appareil.

## V3.2.2 — erreur de compilation corrigée
`incident_screen.dart` construisait un `Incident` sans le champ obligatoire `createdAt` : le build
(`flutter build apk`) aurait échoué sur cette erreur. Corrigé (`createdAt: DateTime.now()`).
Import inutilisé `config.dart` retiré. Relecture statique des 25 fichiers `lib/` : pas d'autre erreur
de compilation repérée (non vérifié par un vrai compilateur).

# Casabaia V3.2 finale — édition gratuite

Application Flutter terrain pour le suivi de la propreté urbaine.

## Fonctions
- GPS du téléphone pour géolocaliser les incidents
- Secteurs : Hay Adil, Belvédère, Roches Noires, Aïn Borja
- Équipes, chefs d'équipe et véhicules
- Points de collecte et statuts
- Incidents avec photo, description et position GPS
- Tournée optimisée localement (plus proche voisin)
- Carte OpenStreetMap
- Tableau de bord superviseur
- Rapport PDF et partage
- Stockage local sur le téléphone
- Aucune clé Google, Firebase ou serveur obligatoire

## Gratuité
Le calcul de tournée est entièrement local. La carte OpenStreetMap utilise Internet pour charger les tuiles lorsqu'elles ne sont pas déjà disponibles. Il n'y a aucune API Google à configurer.

## Générer l'APK
Sur Windows : double-cliquer sur `tool/build_apk_windows.bat`.

Sur macOS/Linux : lancer `tool/build_apk_linux_mac.sh`.

Flutter et Android SDK doivent être installés sur le PC.

L'APK final est créé dans :
`build/app/outputs/flutter-apk/app-release.apk`

## Important
Cette édition ne synchronise pas automatiquement les données vers un serveur. Les données restent sur le téléphone tant qu'aucun module de synchronisation n'est ajouté.

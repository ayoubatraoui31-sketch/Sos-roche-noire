import 'dart:convert';
import 'package:collecte_optimise/config.dart';
import 'package:collecte_optimise/models/collection_point.dart';
import 'package:collecte_optimise/models/tour_session.dart';
import 'package:collecte_optimise/services/directions_service.dart';
import 'package:collecte_optimise/services/tour_controller.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'fakes.dart';

/// Crée un contrôleur de test avec [n] points et un faux Google.
Future<(TourController, FakeFetcher)> setup(int n) async {
  TestWidgetsFlutterBinding.ensureInitialized();
  SharedPreferences.setMockInitialValues({}); // stockage local vide, en mémoire
  final fetcher = FakeFetcher();
  final json = jsonEncode(makePoints(n).map((p) => p.toJson()).toList());
  final c = TourController(
    directions: DirectionsService(fetcher),
    loadPointsJson: () async => json,
  );
  await c.init();
  return (c, fetcher);
}

void main() {
  test('erreur Directions : pas de plantage, message d\'erreur affiché', () async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    final json = jsonEncode(makePoints(3).map((p) => p.toJson()).toList());
    final c = TourController(
      directions: DirectionsService(FailingFetcher()),
      loadPointsJson: () async => json,
    );
    await c.init();
    expect(await c.computeTour(), isFalse);
    expect(c.error, contains('REQUEST_DENIED'));
    expect(c.loading, isFalse);
    expect(c.session, isNull);
  });

  test('init charge les points depuis le JSON', () async {
    final (c, _) = await setup(8);
    expect(c.points.length, 8);
    expect(c.tourPoints.length, 8);
  });

  test('computeTour : session créée, économies = classique - optimisé', () async {
    final (c, f) = await setup(4);
    expect(await c.computeTour(), isTrue);
    expect(f.callCount, 2); // optimisé + classique
    final s = c.session!;
    expect(s.remainingIds.length, 4);
    expect(s.classicMeters, 5 * 1500);
    expect(s.optimizedMeters, 5 * 1000);
    final today = c.savings[TourController.dayKey(DateTime.now())]!;
    expect(today.savedKm, closeTo(2.5, 1e-9));
  });

  test('aucun point dans la tournée : erreur, pas de session', () async {
    final (c, _) = await setup(3);
    await c.selectNone();
    expect(await c.computeTour(), isFalse);
    expect(c.session, isNull);
    expect(c.error, isNotNull);
  });

  test('collecter ne rappelle pas Google à chaque point', () async {
    final (c, f) = await setup(4);
    await c.computeTour();
    final before = f.callCount;
    await c.completeCurrent(); // 1er point collecté
    expect(f.callCount, before); // pas de recalcul
    expect(c.session!.collectedIds.length, 1);
    expect(c.session!.legsMeters.length, 4); // 3 points restants + retour
  });

  test('ignorer un point déclenche un recalcul', () async {
    final (c, f) = await setup(4);
    await c.computeTour();
    final before = f.callCount;
    await c.completeCurrent(skipReason: 'Inaccessible');
    expect(f.callCount, before + 1);
    expect(c.session!.skipped.length, 1);
  });

  test('recalcul automatique tous les AppConfig.recalcEvery points', () async {
    final (c, f) = await setup(AppConfig.recalcEvery + 2);
    await c.computeTour();
    final before = f.callCount;
    for (int i = 0; i < AppConfig.recalcEvery; i++) {
      await c.completeCurrent();
    }
    expect(f.callCount, before + 1);
  });

  test('fin de tournée : session terminée, km parcourus = distance prévue', () async {
    final (c, _) = await setup(3);
    await c.computeTour();
    while (c.currentStop != null) {
      await c.completeCurrent();
    }
    final s = c.session!;
    expect(s.isFinished, isTrue);
    expect(s.collectedIds.length, 3);
    expect(s.traveledMeters, s.optimizedMeters); // 4 tronçons x 1 km
    expect(c.points.every((p) => p.status == PointStatus.collected), isTrue);
  });

  test('startNewDay remet les points à collecter', () async {
    final (c, _) = await setup(2);
    await c.computeTour();
    while (c.currentStop != null) {
      await c.completeCurrent();
    }
    await c.startNewDay();
    expect(c.session, isNull);
    expect(c.points.every((p) => p.status == PointStatus.toCollect), isTrue);
  });

  test('SavingsEntry : jamais négatif', () {
    expect(SavingsEntry(5000, 8000).savedKm, 0);
    expect(SavingsEntry(10000, 7500).savedKm, closeTo(2.5, 1e-9));
  });
}

import 'dart:async';
import 'dart:io';
import 'package:collecte_optimise/services/error_reporter.dart';
import 'package:flutter_test/flutter_test.dart';
import 'fakes.dart';

/// Sink qui plante : l'envoi au SaaS ne doit JAMAIS faire planter l'app.
class _BrokenSink implements ErrorSink {
  @override
  Future<void> capture(Object error, StackTrace stack, {Map<String, String> tags = const {}}) =>
      throw StateError('SaaS injoignable');
  @override
  void breadcrumb(String message, {String category = 'app'}) => throw StateError('boom');
}

void main() {
  tearDown(() => ErrorReporter.sink = SentrySink());

  test('erreurs réseau reconnues', () {
    expect(ErrorReporter.isNetworkError(const SocketException('x')), isTrue);
    expect(ErrorReporter.isNetworkError(TimeoutException('x')), isTrue);
    expect(ErrorReporter.isNetworkError(Exception('REQUEST_DENIED')), isFalse);
  });

  test('une vraie erreur est envoyée au SaaS avec son contexte', () async {
    final sink = installFakeSink();
    await ErrorReporter.report(Exception('REQUEST_DENIED'), StackTrace.current, where: 'computeTour');
    expect(sink.captured.length, 1);
    expect(sink.captured.single.tags['where'], 'computeTour');
  });

  test('une panne réseau n\'est PAS envoyée comme bug (simple trace)', () async {
    final sink = installFakeSink();
    await ErrorReporter.report(const SocketException('hors ligne'), StackTrace.current, where: 'x');
    expect(sink.captured, isEmpty);
    expect(sink.breadcrumbs.single, contains('Réseau indisponible'));
  });

  test('si le SaaS est injoignable, report ne plante pas', () async {
    ErrorReporter.sink = _BrokenSink();
    await ErrorReporter.report(Exception('boom'), StackTrace.current, where: 'x');
    ErrorReporter.breadcrumb('test');
  });

  test('sans Sentry initialisé (DSN vide), les appels sont ignorés sans erreur', () async {
    ErrorReporter.sink = SentrySink();
    await ErrorReporter.report(Exception('boom'), StackTrace.current, where: 'test');
    ErrorReporter.breadcrumb('test');
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:collecte_optimise/models/collection_point.dart';

void main() {
  test('ancien JSON reste compatible avec les champs V2', () {
    final p = CollectionPoint.fromJson({
      'id': 'p1', 'name': 'Benne', 'neighborhood': 'Centre',
      'address': 'Rue 1', 'lat': 33.59, 'lng': -7.58,
      'status': 'toCollect', 'inTodayTour': true,
    });
    expect(p.wasteType, 'ordures_menageres');
    expect(p.fillLevel, 0);
    expect(p.priorityLevel, 1);
    expect(p.serviceMinutes, 3);
  });
}

import 'package:collecte_optimise/models/collection_point.dart';
import 'package:collecte_optimise/screens/map_screen.dart';
import 'package:collecte_optimise/services/error_reporter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'fakes.dart';
import 'widget_helpers.dart';

void main() {
  setUp(installFakeMap);
  tearDown(() {
    resetGlobals();
    ErrorReporter.sink = SentrySink();
  });

  testWidgets('affiche un marqueur par point et le bouton de calcul', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 4);
    await tester.pumpWidget(wrap(MapScreen(controller: c)));

    expect(lastMap.markers.length, 4);
    expect(lastMap.polylines, isEmpty); // pas encore d'itinéraire
    expect(find.text("Calculer l'itinéraire"), findsOneWidget);
    expect(find.text('Démarrer la navigation'), findsNothing);
    // légende des couleurs
    expect(find.text('À collecter'), findsOneWidget);
    expect(find.text('Collecté'), findsOneWidget);
    expect(find.text('Prioritaire'), findsOneWidget);
  });

  testWidgets('un point hors tournée est estompé sur la carte', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await c.toggleInTour(c.points.first); // retire p0 de la tournée
    await tester.pumpWidget(wrap(MapScreen(controller: c)));

    expect(lastMap.markers.length, 3);
    expect(c.points.first.inTodayTour, false);
  });

  testWidgets('calculer l\'itinéraire : polyline, distance, durée, bouton de navigation', (tester) async {
    bigScreen(tester);
    final (c, f) = await makeController(n: 3);
    await tester.pumpWidget(wrap(MapScreen(controller: c)));

    await tester.tap(find.text("Calculer l'itinéraire"));
    await tester.pumpAndSettle();

    expect(f.callCount, 2); // optimisé + classique
    expect(lastMap.polylines.length, 1);
    expect(lastMap.polylines.single.color, Colors.blue);
    expect(lastMap.polylines.single.points.length, 3);
    expect(find.textContaining('4.0 km'), findsOneWidget); // 4 tronçons x 1 km
    expect(find.textContaining('4 min'), findsOneWidget);
    expect(find.text('Démarrer la navigation'), findsOneWidget);
    expect(find.text("Calculer l'itinéraire"), findsNothing);
  });

  testWidgets('erreur Directions : message rouge à l\'écran ET envoyé au SaaS', (tester) async {
    bigScreen(tester);
    final sink = installFakeSink();
    final fetcher = FakeFetcher()..error = Exception('REQUEST_DENIED');
    final (c, _) = await makeController(n: 3, fetcher: fetcher);
    await tester.pumpWidget(wrap(MapScreen(controller: c)));

    await tester.tap(find.text("Calculer l'itinéraire"));
    await tester.pumpAndSettle();

    expect(find.textContaining('REQUEST_DENIED'), findsOneWidget);
    expect(find.text("Calculer l'itinéraire"), findsOneWidget); // on peut réessayer
    expect(sink.captured.single.tags['where'], 'computeTour');
  });

  testWidgets('"Démarrer la navigation" ouvre l\'écran de guidage', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await c.computeTour();
    await tester.pumpWidget(wrap(MapScreen(controller: c)));

    await tester.tap(find.text('Démarrer la navigation'));
    await tester.pumpAndSettle();

    expect(find.text('Point collecté ✓'), findsOneWidget);
    expect(find.text('Point 0'), findsOneWidget);
  });

  testWidgets('le bouton liste ouvre la tournée du jour (3/3)', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await tester.pumpWidget(wrap(MapScreen(controller: c)));

    await tester.tap(find.byIcon(Icons.list_alt));
    await tester.pumpAndSettle();
    expect(find.textContaining('(3/3)'), findsOneWidget);
  });

  testWidgets('le bouton langue bascule en arabe puis en français', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 2);
    await tester.pumpWidget(wrap(MapScreen(controller: c)));

    await tester.tap(find.byIcon(Icons.translate));
    await tester.pumpAndSettle();
    expect(find.text('حساب المسار'), findsOneWidget);
    expect(find.text("Calculer l'itinéraire"), findsNothing);

    await tester.tap(find.byIcon(Icons.translate));
    await tester.pumpAndSettle();
    expect(find.text("Calculer l'itinéraire"), findsOneWidget);
  });

  testWidgets('tournée terminée : bouton "Nouvelle journée" remet les points à collecter', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 2);
    await c.computeTour();
    while (c.currentStop != null) {
      await c.completeCurrent();
    }
    await tester.pumpWidget(wrap(MapScreen(controller: c)));
    expect(find.text('Nouvelle journée'), findsOneWidget);
    expect(c.points.every((p) => p.status == PointStatus.collected), isTrue);

    await tester.tap(find.text('Nouvelle journée'));
    await tester.pumpAndSettle();
    expect(c.session, isNull);
    expect(find.text("Calculer l'itinéraire"), findsOneWidget);
  });
}

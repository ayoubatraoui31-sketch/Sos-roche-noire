import 'package:collecte_optimise/models/collection_point.dart';
import 'package:collecte_optimise/services/directions_service.dart';
import 'package:collecte_optimise/services/error_reporter.dart';
import 'package:latlong2/latlong.dart';

/// Faux "Google" : garde l'ordre donné, 1 km par tronçon (optimisé)
/// ou 1,5 km (non optimisé), et compte les appels.
/// Tracé au format du calcul local (3 points).
const samplePolyline = 'local:[[33.59,-7.57],[33.6,-7.58],[33.61,-7.59]]';

class FakeFetcher implements RouteFetcher {
  final List<int> calls = []; // nombre de points de chaque appel
  int get callCount => calls.length;

  /// Si non null, chaque appel lève cette erreur (simule panne / clé refusée).
  Object? error;

  @override
  Future<RouteResult> fetch({
    required LatLng origin,
    required LatLng destination,
    required List<CollectionPoint> stops,
    required bool optimize,
  }) async {
    calls.add(stops.length);
    if (error != null) throw error!;
    final per = optimize ? 1000 : 1500;
    final legs = List.filled(stops.length + 1, per); // points + destination
    return RouteResult(stops, legs, List.filled(legs.length, 60), samplePolyline);
  }
}

List<CollectionPoint> makePoints(int n) => List.generate(
      n,
      (i) => CollectionPoint(
        id: 'p$i',
        name: 'Point $i',
        neighborhood: 'Test',
        address: '',
        lat: 33.59 + i * 0.001,
        lng: -7.57 + (i % 7) * 0.001,
      ),
    );

/// Faux Google qui échoue toujours (ex. clé API refusée).
class FailingFetcher implements RouteFetcher {
  @override
  Future<RouteResult> fetch({
    required LatLng origin,
    required LatLng destination,
    required List<CollectionPoint> stops,
    required bool optimize,
  }) async =>
      throw Exception('Directions API : REQUEST_DENIED');
}

/// Faux "SaaS" : mémorise ce que l'application lui envoie.
class FakeSink implements ErrorSink {
  final List<({Object error, Map<String, String> tags})> captured = [];
  final List<String> breadcrumbs = [];

  @override
  Future<void> capture(Object error, StackTrace stack, {Map<String, String> tags = const {}}) async =>
      captured.add((error: error, tags: tags));

  @override
  void breadcrumb(String message, {String category = 'app'}) => breadcrumbs.add(message);
}

/// Branche un [FakeSink] à la place de Sentry pour la durée du test.
FakeSink installFakeSink() {
  final s = FakeSink();
  ErrorReporter.sink = s;
  return s;
}

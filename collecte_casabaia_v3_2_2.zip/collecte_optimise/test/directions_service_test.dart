import 'package:collecte_optimise/models/collection_point.dart';
import 'package:collecte_optimise/services/directions_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'fakes.dart';

CollectionPoint pt(String id, double lat, double lng) => CollectionPoint(
    id: id, name: id, neighborhood: 'Test', address: '', lat: lat, lng: lng);

void main() {
  const depot = LatLng(33.59, -7.58);
  final service = DirectionsService(LocalRouteFetcher());

  test('distance : 0,01° de latitude = environ 1 112 m, aller-retour', () async {
    final r = await service.fetchTour(
        origin: depot, destination: depot, stops: [pt('a', 33.60, -7.58)], optimize: true);
    expect(r.legsMeters.length, 2); // aller + retour dépôt
    expect(r.legsMeters[0], closeTo(1112, 5));
    expect(r.legsMeters[1], closeTo(1112, 5));
    // 25 km/h : 1112 m = environ 160 s
    expect(r.legsSeconds[0], closeTo(160, 3));
  });

  test('aucun point : seulement le trajet départ -> arrivée', () async {
    final r = await service.fetchTour(origin: depot, destination: depot, stops: [], optimize: true);
    expect(r.orderedStops, isEmpty);
    expect(r.legsMeters.length, 1);
    expect(r.totalMeters, 0);
  });

  test('50 points : aucun oubli, aucun doublon, 51 tronçons', () async {
    final pts = makePoints(50);
    final r = await service.fetchTour(origin: depot, destination: depot, stops: pts, optimize: true);
    final ids = r.orderedStops.map((p) => p.id).toList();
    expect(ids.length, 50);
    expect(ids.toSet(), pts.map((p) => p.id).toSet());
    expect(r.legsMeters.length, 51);
  });

  test('mode classique : l\'ordre de la liste est conservé', () async {
    final pts = makePoints(40);
    final r = await service.fetchTour(origin: depot, destination: depot, stops: pts, optimize: false);
    expect(r.orderedStops.map((p) => p.id).toList(), pts.map((p) => p.id).toList());
  });

  test('optimisé plus court que classique sur un parcours en zigzag', () async {
    final zigzag = [
      pt('nord1', 33.620, -7.58),
      pt('sud1', 33.591, -7.58),
      pt('nord2', 33.621, -7.58),
      pt('sud2', 33.592, -7.58),
    ];
    final classic = await service.fetchTour(origin: depot, destination: depot, stops: zigzag, optimize: false);
    final optim = await service.fetchTour(origin: depot, destination: depot, stops: zigzag, optimize: true);
    expect(optim.totalMeters, lessThan(classic.totalMeters));
    expect(optim.orderedStops.first.id, 'sud1'); // le plus proche d'abord
  });

  test('plus proche voisin : commence par le point le plus proche', () {
    final order = DirectionsService.nearestNeighborOrder(const LatLng(33.59, -7.57), makePoints(5));
    expect(order.first.id, 'p0');
    expect(order.length, 5);
  });

  test('le tracé décodé passe par départ, points, arrivée', () async {
    final pts = makePoints(3);
    final r = await service.fetchTour(origin: depot, destination: depot, stops: pts, optimize: false);
    final line = DirectionsService.decodePolyline(r.polyline);
    expect(line.length, 5); // départ + 3 points + arrivée
    expect(line.first.latitude, closeTo(depot.latitude, 1e-9));
    expect(line[1].latitude, closeTo(pts[0].lat, 1e-9));
  });

  test('tracé inconnu ou vide : liste vide, sans planter', () {
    expect(DirectionsService.decodePolyline(''), isEmpty);
    expect(DirectionsService.decodePolyline('format-inconnu'), isEmpty);
  });
}

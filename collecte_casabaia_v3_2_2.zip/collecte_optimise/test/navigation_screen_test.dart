import 'dart:io';
import 'package:collecte_optimise/models/collection_point.dart';
import 'package:collecte_optimise/screens/navigation_screen.dart';
import 'package:collecte_optimise/services/error_reporter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'fakes.dart';
import 'widget_helpers.dart';

void main() {
  setUp(installFakeMap);
  tearDown(() {
    resetGlobals();
    ErrorReporter.sink = SentrySink();
  });

  testWidgets('sans tournée : message "Aucune tournée"', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));
    expect(find.textContaining('Aucune tournée'), findsOneWidget);
    expect(find.text('Point collecté ✓'), findsNothing);
  });

  testWidgets('affiche le point actuel, le quartier et les distances', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await c.computeTour();
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));

    expect(find.text('Point actuel 1/3'), findsOneWidget);
    expect(find.text('Point 0'), findsOneWidget);
    expect(find.textContaining('Test'), findsOneWidget); // quartier
    expect(find.textContaining("Distance jusqu'au point : 1.0 km"), findsOneWidget);
    expect(find.textContaining('Distance restante : 4.0 km'), findsOneWidget);
    expect(find.text('Point collecté ✓'), findsOneWidget);
    expect(find.text('Ignorer ce point'), findsOneWidget);
    // mini-carte : un seul marqueur (le point actuel) + l'itinéraire bleu
    expect(lastMap.markers.single.point.latitude, closeTo(33.59, 0.01));
    expect(lastMap.polylines.length, 1);
  });

  testWidgets('"Point collecté ✓" passe au point suivant', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await c.computeTour();
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));

    await tester.tap(find.text('Point collecté ✓'));
    await tester.pumpAndSettle();

    expect(find.text('Point actuel 2/3'), findsOneWidget);
    expect(find.text('Point 1'), findsOneWidget);
    expect(find.text('Point 0'), findsNothing);
    expect(lastMap.markers.single.point.latitude, closeTo(33.591, 0.01));
    expect(c.session!.collectedIds, ['p0']);
    expect(c.points.first.status, PointStatus.collected);
    expect(find.textContaining('Distance restante : 3.0 km'), findsOneWidget);
  });

  testWidgets('"Ignorer ce point" : motifs proposés, point marqué ignoré', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await c.computeTour();
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));

    await tester.tap(find.text('Ignorer ce point'));
    await tester.pumpAndSettle();
    expect(find.text('Motif :'), findsOneWidget);
    for (final r in ['Conteneur vide', 'Inaccessible', 'Route bloquée', 'Autre']) {
      expect(find.text(r), findsOneWidget);
    }

    await tester.tap(find.text('Inaccessible'));
    await tester.pumpAndSettle();

    expect(find.text('Motif :'), findsNothing); // dialogue fermé
    expect(c.session!.skipped, {'p0': 'Inaccessible'});
    expect(c.points.first.status, PointStatus.skipped);
    expect(find.text('Point actuel 2/3'), findsOneWidget);
  });

  testWidgets('ignorer un point recalcule l\'itinéraire (2 appels de plus)', (tester) async {
    bigScreen(tester);
    final (c, f) = await makeController(n: 3);
    await c.computeTour();
    final before = f.callCount;
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));

    await tester.tap(find.text('Ignorer ce point'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Autre'));
    await tester.pumpAndSettle();
    expect(f.callCount, before + 1);
  });

  testWidgets('hors ligne au recalcul : la navigation continue, aucune alerte de bug', (tester) async {
    bigScreen(tester);
    final sink = installFakeSink();
    final (c, f) = await makeController(n: 3);
    await c.computeTour();
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));

    f.error = const SocketException('hors ligne'); // plus de réseau
    await tester.tap(find.text('Ignorer ce point'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Autre'));
    await tester.pumpAndSettle();

    expect(find.text('Point actuel 2/3'), findsOneWidget); // l'écran continue
    expect(sink.captured, isEmpty); // panne réseau = pas un bug
    expect(sink.breadcrumbs.any((b) => b.contains('Réseau indisponible')), isTrue);
  });

  testWidgets('erreur serveur au recalcul : navigation continue ET alerte envoyée', (tester) async {
    bigScreen(tester);
    final sink = installFakeSink();
    final (c, f) = await makeController(n: 3);
    await c.computeTour();
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));

    f.error = Exception('OVER_QUERY_LIMIT');
    await tester.tap(find.text('Ignorer ce point'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Autre'));
    await tester.pumpAndSettle();

    expect(find.text('Point actuel 2/3'), findsOneWidget);
    expect(sink.captured.single.tags['where'], 'recalculateRemaining');
  });

  testWidgets('parcours complet : dernier point -> "Tournée terminée" -> rapport', (tester) async {
    bigScreen(tester);
    final (c, _) = await makeController(n: 3);
    await c.computeTour();
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));

    for (int i = 0; i < 3; i++) {
      await tester.tap(find.text('Point collecté ✓'));
      await tester.pumpAndSettle();
    }
    expect(find.textContaining('Tournée terminée'), findsOneWidget);
    expect(find.text('Voir le rapport'), findsOneWidget);
    expect(c.session!.isFinished, isTrue);

    await tester.tap(find.text('Voir le rapport'));
    await tester.pumpAndSettle();
    expect(find.text('Exporter en PDF'), findsOneWidget);
    expect(find.text('Points collectés'), findsOneWidget);
  });

  testWidgets('les fils d\'Ariane Sentry suivent le parcours du conducteur', (tester) async {
    bigScreen(tester);
    final sink = installFakeSink();
    final (c, _) = await makeController(n: 2);
    await c.computeTour();
    await tester.pumpWidget(wrap(NavigationScreen(controller: c)));
    await tester.tap(find.text('Point collecté ✓'));
    await tester.pumpAndSettle();

    expect(sink.breadcrumbs.any((b) => b.startsWith('Tournée calculée')), isTrue);
    expect(sink.breadcrumbs.contains('Point collecté p0'), isTrue);
  });
}

import 'dart:convert';
import 'package:collecte_optimise/l10n/app_strings.dart';
import 'package:collecte_optimise/services/directions_service.dart';
import 'package:collecte_optimise/services/tour_controller.dart';
import 'package:collecte_optimise/widgets/app_map.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'fakes.dart';

/// Dernière carte "affichée" : permet de vérifier marqueurs et polylines.
AppMap? _lastMap;
AppMap get lastMap => _lastMap!;

/// Remplace Google Maps par un widget vide qui mémorise ses paramètres.
void installFakeMap() {
  AppMap.builder = (m) {
    _lastMap = m;
    return const SizedBox.expand(key: ValueKey('fake-map'));
  };
}

/// À appeler dans tearDown : remet les réglages globaux à zéro.
void resetGlobals() {
  S.lang = 'fr';
  _lastMap = null;
}

/// Contrôleur de test avec [n] points et un faux Google (ordre conservé).
Future<(TourController, FakeFetcher)> makeController({int n = 3, FakeFetcher? fetcher}) async {
  SharedPreferences.setMockInitialValues({});
  final f = fetcher ?? FakeFetcher();
  final json = jsonEncode(makePoints(n).map((p) => p.toJson()).toList());
  final c = TourController(directions: DirectionsService(f), loadPointsJson: () async => json);
  await c.init();
  return (c, f);
}

/// Grand écran logique (540 x 1100) pour éviter les faux "overflow" des tests.
void bigScreen(WidgetTester tester) {
  tester.view.physicalSize = const Size(1080, 2200);
  tester.view.devicePixelRatio = 2.0;
  addTearDown(tester.view.reset);
}

Widget wrap(Widget screen) => MaterialApp(home: screen);

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class AppMap extends StatelessWidget {
  const AppMap({super.key, required this.target, required this.zoom, this.markers = const [], this.polylines = const []});
  final LatLng target;
  final double zoom;
  final List<Marker> markers;
  final List<Polyline> polylines;

  static Widget Function(AppMap map) builder = _build;

  static Widget _build(AppMap m) => FlutterMap(
    options: MapOptions(initialCenter: m.target, initialZoom: m.zoom),
    children: [
      TileLayer(
        urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        userAgentPackageName: 'ma.casabaia.collecte_optimise',
      ),
      if (polylines.isNotEmpty) PolylineLayer(polylines: polylines),
      if (markers.isNotEmpty) MarkerLayer(markers: markers),
      RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
    ],
  );

  @override
  Widget build(BuildContext context) => builder(this);
}

import 'package:flutter/material.dart';
import '../models/collection_point.dart';

Color statusColor(PointStatus s) {
  switch (s) {
    case PointStatus.toCollect: return Colors.green;
    case PointStatus.collected: return Colors.grey;
    case PointStatus.priority: return Colors.red;
    case PointStatus.skipped: return Colors.orange;
  }
}

class MarkerIcons {
  static Widget of(PointStatus s, {double opacity = 1}) => Opacity(
    opacity: opacity,
    child: Icon(Icons.delete, color: statusColor(s), size: 34),
  );
}

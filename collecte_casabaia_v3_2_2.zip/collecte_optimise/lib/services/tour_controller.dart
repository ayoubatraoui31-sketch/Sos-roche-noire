import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:latlong2/latlong.dart';
import '../config.dart';
import '../l10n/app_strings.dart';
import '../models/collection_point.dart';
import '../models/tour_session.dart';
import 'error_reporter.dart';
import 'directions_service.dart';
import 'storage_service.dart';
import 'incident_service.dart';
import '../models/incident.dart';
import '../models/operational_profile.dart';

/// "Cerveau" de l'application : garde les points, la tournée en cours et
/// les économies. Les écrans écoutent ce contrôleur et se mettent à jour
/// automatiquement quand on appelle notifyListeners().
class TourController extends ChangeNotifier {
  /// Les dépendances sont injectées : les tests passent de faux services.
  TourController({
    required DirectionsService directions,
    StorageService? storage,
    Future<String> Function()? loadPointsJson,
    this.depot = const LatLng(AppConfig.depotLat, AppConfig.depotLng),
  })  : _directions = directions,
        _storage = storage ?? StorageService(),
        _loadPointsJson = loadPointsJson ?? (() => rootBundle.loadString('assets/points.json'));

  /// Instance utilisée par l'application réelle.
  static final TourController instance =
      TourController(directions: DirectionsService(LocalRouteFetcher()));

  final DirectionsService _directions;
  final StorageService _storage;
  final IncidentService _incidentService = IncidentService();
  final Future<String> Function() _loadPointsJson;
  final LatLng depot;
  int _collectedSinceRecalc = 0; // fréquence du recalcul local

  List<CollectionPoint> points = [];
  TourSession? session;
  Map<String, SavingsEntry> savings = {};
  bool loading = false;
  String? error;
  List<Incident> incidents = [];
  OperationalProfile profile = const OperationalProfile(sector: 'Hay Adil', depotName: 'Dépôt Casabaia', vehicleId: 'CAM-01', driverName: 'À affecter', teamLeaderName: 'Goumni Mohamed');

  // ---------- Démarrage ----------
  Future<void> init() async {
    S.lang = await _storage.loadLang();
    points = await _storage.loadPoints();
    if (points.isEmpty) {
      await reloadFromAsset(); // première ouverture : charge assets/points.json
    }
    session = await _storage.loadSession();
    savings = await _storage.loadSavings();
    incidents = await _incidentService.load();
  }

  /// Charge les 50 points depuis assets/points.json (efface la liste actuelle
  /// et la tournée en cours).
  Future<void> reloadFromAsset() async {
    final raw = await _loadPointsJson();
    points = (jsonDecode(raw) as List).map((e) => CollectionPoint.fromJson(e)).toList();
    session = null;
    _collectedSinceRecalc = 0;
    await _storage.savePoints(points);
    await _storage.saveSession(null);
    notifyListeners();
  }

  /// Sélection rapide de la tournée : un quartier ([quartier]) ou tous (null).
  Future<void> selectOnly(String? quartier) async {
    for (final p in points) {
      p.inTodayTour = quartier == null || p.neighborhood == quartier;
    }
    await _storage.savePoints(points);
    notifyListeners();
  }

  Future<void> selectNone() async {
    for (final p in points) {
      p.inTodayTour = false;
    }
    await _storage.savePoints(points);
    notifyListeners();
  }

  // ---------- Accès pratiques ----------
  List<CollectionPoint> get tourPoints => points.where((p) => p.inTodayTour).toList();

  CollectionPoint? byId(String id) {
    for (final p in points) {
      if (p.id == id) return p;
    }
    return null;
  }

  /// Point que le conducteur doit rejoindre maintenant.
  CollectionPoint? get currentStop {
    final s = session;
    if (s == null || s.isFinished || s.remainingIds.isEmpty) return null;
    return byId(s.remainingIds.first);
  }

  static String dayKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  // ---------- Langue ----------
  Future<void> setLang(String lang) async {
    S.lang = lang;
    await _storage.saveLang(lang);
    notifyListeners();
  }

  // ---------- Gestion des points ----------
  Future<void> addPoint(CollectionPoint p) async {
    points.add(p);
    await _storage.savePoints(points);
    notifyListeners();
  }

  Future<void> removePoint(String id) async {
    points.removeWhere((p) => p.id == id);
    await _storage.savePoints(points);
    notifyListeners();
  }

  Future<void> toggleInTour(CollectionPoint p) async {
    p.inTodayTour = !p.inTodayTour;
    await _storage.savePoints(points);
    notifyListeners();
  }

  Future<void> setStatus(CollectionPoint p, PointStatus s) async {
    p.status = s;
    await _storage.savePoints(points);
    notifyListeners();
  }

  /// Pas de synchronisation serveur dans cette édition gratuite :
  /// les données restent sur le téléphone.
  Future<void> syncWithServer() async {
    // TODO: http.post(...) vers votre serveur, puis points = ...; savePoints
    await Future.delayed(const Duration(milliseconds: 500));
  }


  Future<void> addIncident(Incident incident) async {
    incidents.insert(0, incident);
    await _incidentService.save(incidents);
    notifyListeners();
  }

  Future<void> closeIncident(String id) async {
    final i = incidents.indexWhere((e) => e.id == id);
    if (i < 0) return;
    final old = incidents[i];
    incidents[i] = Incident(id: old.id, pointId: old.pointId, sector: old.sector, type: old.type, description: old.description, photoPath: old.photoPath, lat: old.lat, lng: old.lng, createdAt: old.createdAt, status: 'clos');
    await _incidentService.save(incidents);
    notifyListeners();
  }

  Future<void> setOperationalProfile(OperationalProfile value) async {
    profile = value;
    notifyListeners();
  }

  Future<void> refreshOperationalData() async {
    incidents = await _incidentService.load();
    notifyListeners();
  }

  // ---------- Optimisation de la tournée ----------
  /// Calcule localement l'itinéraire optimisé et classique, puis
  /// sauvegarde le résultat. Aucune API externe n'est utilisée.
  Future<bool> computeTour() async {
    final stops = tourPoints
        .where((p) => p.status != PointStatus.collected && p.status != PointStatus.skipped)
        .toList();
    if (stops.isEmpty) {
      error = S.t('no_points_tour');
      notifyListeners();
      return false;
    }
    loading = true;
    error = null;
    notifyListeners();
    try {
      final optimized = await _directions.fetchTour(
          origin: depot, destination: depot, stops: stops, optimize: true);
      final classic = await _directions.fetchTour(
          origin: depot, destination: depot, stops: stops, optimize: false);

      session = TourSession(
        remainingIds: optimized.orderedStops.map((p) => p.id).toList(),
        legsMeters: optimized.legsMeters,
        legsSeconds: optimized.legsSeconds,
        encodedPolyline: optimized.polyline,
        classicMeters: classic.totalMeters,
        optimizedMeters: optimized.totalMeters,
        optimizedSeconds: optimized.totalSeconds,
        totalStops: stops.length,
        startedAt: DateTime.now(),
      );
      savings[dayKey(DateTime.now())] =
          SavingsEntry(classic.totalMeters, optimized.totalMeters);
      await _storage.saveSession(session);
      await _storage.saveSavings(savings);
      ErrorReporter.breadcrumb('Tournée calculée : ${stops.length} points, '
          '${classic.totalMeters ~/ 1000} km classique / ${optimized.totalMeters ~/ 1000} km optimisé');
      return true;
    } catch (e, st) {
      error = e.toString();
      await ErrorReporter.report(e, st, where: 'computeTour');
      return false;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  // ---------- Navigation guidée ----------
  /// Appelé par "Point collecté ✓" (skipReason == null)
  /// ou par "Ignorer ce point" (skipReason = motif).
  Future<void> completeCurrent({String? skipReason}) async {
    final s = session;
    final p = currentStop;
    if (s == null || p == null) return;

    // La distance du tronçon vers ce point est maintenant parcourue.
    s.traveledMeters += s.legsMeters.first;
    s.remainingIds.removeAt(0);
    s.lastPointId = p.id;
    ErrorReporter.breadcrumb(skipReason == null
        ? 'Point collecté ${p.id}'
        : 'Point ignoré ${p.id} ($skipReason)');

    if (skipReason == null) {
      p.status = PointStatus.collected;
      s.collectedIds.add(p.id);
    } else {
      p.status = PointStatus.skipped;
      s.skipped[p.id] = skipReason;
    }

    if (s.remainingIds.isEmpty) {
      // Dernier point : on ajoute le retour au dépôt et on termine.
      if (s.legsMeters.length > 1) s.traveledMeters += s.legsMeters[1];
      s.legsMeters = [];
      s.legsSeconds = [];
      s.encodedPolyline = '';
      s.finishedAt = DateTime.now();
    } else {
      // Recalcul local après un point ignoré, ou selon la fréquence configurée. Sinon l'ordre prévu reste optimal :
      // on retire simplement le tronçon déjà parcouru.
      _collectedSinceRecalc++;
      if (skipReason != null || _collectedSinceRecalc >= AppConfig.recalcEvery) {
        _collectedSinceRecalc = 0;
        await _recalculateRemaining(s, p);
      } else {
        _dropFirstLeg(s);
      }
    }
    await _storage.savePoints(points);
    await _storage.saveSession(s);
    notifyListeners();
  }

  /// Recalcule le trajet restant depuis le point qu'on vient de quitter, localement.
  Future<void> _recalculateRemaining(TourSession s, CollectionPoint from) async {
    final remaining = s.remainingIds.map(byId).whereType<CollectionPoint>().toList();
    try {
      final r = await _directions.fetchTour(
        origin: LatLng(from.lat, from.lng),
        destination: depot,
        stops: remaining,
        optimize: true,
      );
      s.remainingIds = r.orderedStops.map((p) => p.id).toList();
      s.legsMeters = r.legsMeters;
      s.legsSeconds = r.legsSeconds;
      s.encodedPolyline = r.polyline;
    } catch (e, st) {
      await ErrorReporter.report(e, st, where: 'recalculateRemaining');
      _dropFirstLeg(s); // hors ligne : on garde l'itinéraire sauvegardé
    }
  }

  void _dropFirstLeg(TourSession s) {
    if (s.legsMeters.isNotEmpty) s.legsMeters.removeAt(0);
    if (s.legsSeconds.isNotEmpty) s.legsSeconds.removeAt(0);
  }

  /// Remet les points à "à collecter" et efface la tournée (nouvelle journée).
  Future<void> startNewDay() async {
    for (final p in points) {
      if (p.status == PointStatus.collected || p.status == PointStatus.skipped) {
        p.status = PointStatus.toCollect;
      }
    }
    session = null;
    await _storage.savePoints(points);
    await _storage.saveSession(null);
    notifyListeners();
  }
}

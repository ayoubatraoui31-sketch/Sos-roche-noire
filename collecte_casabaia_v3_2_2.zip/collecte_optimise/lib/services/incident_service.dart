import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/incident.dart';

class IncidentService {
  static const _key = 'casabaia_incidents_v1';

  Future<List<Incident>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    return (jsonDecode(raw) as List)
        .map((e) => Incident.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> save(List<Incident> incidents) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(incidents.map((e) => e.toJson()).toList()));
  }
}

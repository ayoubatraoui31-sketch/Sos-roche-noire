import 'dart:convert';
import 'dart:math';
import 'package:latlong2/latlong.dart';
import '../models/collection_point.dart';

class RouteResult {
  final List<CollectionPoint> orderedStops;
  final List<int> legsMeters;
  final List<int> legsSeconds;
  final String polyline;
  RouteResult(this.orderedStops, this.legsMeters, this.legsSeconds, this.polyline);
  int get totalMeters => legsMeters.fold(0, (a, b) => a + b);
  int get totalSeconds => legsSeconds.fold(0, (a, b) => a + b);
}

abstract class RouteFetcher {
  Future<RouteResult> fetch({
    required LatLng origin,
    required LatLng destination,
    required List<CollectionPoint> stops,
    required bool optimize,
  });
}

/// Calcul local, sans Google, sans clé API et sans serveur.
/// L'ordre optimisé utilise le plus proche voisin et les distances GPS en ligne droite.
class LocalRouteFetcher implements RouteFetcher {
  static const double averageSpeedKmh = 25.0;

  @override
  Future<RouteResult> fetch({
    required LatLng origin,
    required LatLng destination,
    required List<CollectionPoint> stops,
    required bool optimize,
  }) async {
    final ordered = optimize
        ? DirectionsService.nearestNeighborOrder(origin, stops)
        : List<CollectionPoint>.from(stops);
    final all = <LatLng>[origin, ...ordered.map((p) => LatLng(p.lat, p.lng)), destination];
    final meters = <int>[];
    final seconds = <int>[];
    for (var i = 0; i < all.length - 1; i++) {
      final m = _distanceMeters(all[i], all[i + 1]).round();
      meters.add(m);
      seconds.add((m / 1000 / averageSpeedKmh * 3600).round());
    }
    return RouteResult(ordered, meters, seconds, _encodeLocal(all));
  }

  static double _distanceMeters(LatLng a, LatLng b) {
    const r = 6371000.0;
    final p1 = a.latitude * pi / 180;
    final p2 = b.latitude * pi / 180;
    final dp = (b.latitude - a.latitude) * pi / 180;
    final dl = (b.longitude - a.longitude) * pi / 180;
    final h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2);
    return 2 * r * asin(sqrt(h));
  }

  static String _encodeLocal(List<LatLng> points) =>
      'local:${jsonEncode(points.map((p) => [p.latitude, p.longitude]).toList())}';
}

/// Service de tournée entièrement local.
class DirectionsService {
  DirectionsService(this._fetcher);
  final RouteFetcher _fetcher;

  Future<RouteResult> fetchTour({
    required LatLng origin,
    required LatLng destination,
    required List<CollectionPoint> stops,
    required bool optimize,
  }) => _fetcher.fetch(origin: origin, destination: destination, stops: stops, optimize: optimize);

  static List<CollectionPoint> nearestNeighborOrder(LatLng start, List<CollectionPoint> pts) {
    final left = [...pts];
    final out = <CollectionPoint>[];
    var cur = start;
    while (left.isNotEmpty) {
      left.sort((a, b) => _d(cur, a).compareTo(_d(cur, b)));
      final n = left.removeAt(0);
      out.add(n);
      cur = LatLng(n.lat, n.lng);
    }
    return out;
  }

  static double _d(LatLng a, CollectionPoint b) =>
      pow(a.latitude - b.lat, 2).toDouble() + pow(a.longitude - b.lng, 2).toDouble();

  static List<LatLng> decodePolyline(String encoded) {
    if (encoded.startsWith('local:')) {
      final raw = jsonDecode(encoded.substring(6)) as List;
      return raw.map((p) => LatLng((p[0] as num).toDouble(), (p[1] as num).toDouble())).toList();
    }
    return const [];
  }
}

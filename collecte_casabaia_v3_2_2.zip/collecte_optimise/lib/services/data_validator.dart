import '../config.dart';
import '../models/collection_point.dart';

class DataValidationIssue {
  final String pointId;
  final String message;
  const DataValidationIssue(this.pointId, this.message);
}

/// Validation légère des points avant calcul d’une tournée.
class DataValidator {
  static List<DataValidationIssue> validatePoints(List<CollectionPoint> points) {
    final issues = <DataValidationIssue>[];
    final ids = <String>{};
    for (final p in points) {
      if (!ids.add(p.id)) {
        issues.add(DataValidationIssue(p.id, 'ID dupliqué'));
      }
      if (p.lat < -90 || p.lat > 90 || p.lng < -180 || p.lng > 180) {
        issues.add(DataValidationIssue(p.id, 'Coordonnées GPS invalides'));
      }
      if (p.serviceMinutes < 1 || p.serviceMinutes > AppConfig.maxServiceMinutesPerPoint) {
        issues.add(DataValidationIssue(p.id, 'Durée de collecte invalide'));
      }
    }
    return issues;
  }
}

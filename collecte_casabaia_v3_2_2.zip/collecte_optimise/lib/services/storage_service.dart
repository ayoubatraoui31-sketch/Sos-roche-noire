import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/collection_point.dart';
import '../models/tour_session.dart';

/// Lecture/écriture locale (fonctionne hors ligne).
/// Tout est stocké en texte JSON dans shared_preferences.
class StorageService {
  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  Future<List<CollectionPoint>> loadPoints() async {
    final raw = (await _prefs).getString('points');
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => CollectionPoint.fromJson(e))
        .toList();
  }

  Future<void> savePoints(List<CollectionPoint> pts) async =>
      (await _prefs).setString('points', jsonEncode(pts.map((p) => p.toJson()).toList()));

  Future<TourSession?> loadSession() async {
    final raw = (await _prefs).getString('session');
    return raw == null ? null : TourSession.fromJson(jsonDecode(raw));
  }

  Future<void> saveSession(TourSession? s) async {
    final p = await _prefs;
    if (s == null) {
      await p.remove('session');
    } else {
      await p.setString('session', jsonEncode(s.toJson()));
    }
  }

  /// Économies : { "2026-10-04": SavingsEntry, ... }
  Future<Map<String, SavingsEntry>> loadSavings() async {
    final raw = (await _prefs).getString('savings');
    if (raw == null) return {};
    return (jsonDecode(raw) as Map<String, dynamic>)
        .map((k, v) => MapEntry(k, SavingsEntry.fromJson(v)));
  }

  Future<void> saveSavings(Map<String, SavingsEntry> m) async =>
      (await _prefs).setString('savings', jsonEncode(m.map((k, v) => MapEntry(k, v.toJson()))));

  Future<String> loadLang() async => (await _prefs).getString('lang') ?? 'fr';
  Future<void> saveLang(String l) async => (await _prefs).setString('lang', l);
}

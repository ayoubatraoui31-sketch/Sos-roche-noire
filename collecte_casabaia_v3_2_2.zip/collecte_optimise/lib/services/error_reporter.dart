import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';

abstract class ErrorSink {
  Future<void> capture(Object error, StackTrace stack, {Map<String, String> tags = const {}});
  void breadcrumb(String message, {String category = 'app'});
}

/// (Nom historique conservé pour les tests.) Journal local : aucun envoi vers un SaaS et aucune clé requise.
class SentrySink implements ErrorSink {
  @override
  Future<void> capture(Object error, StackTrace stack, {Map<String, String> tags = const {}}) async {
    debugPrint('[Casabaia] $error ${tags.isEmpty ? '' : tags}');
  }
  @override
  void breadcrumb(String message, {String category = 'app'}) =>
      debugPrint('[Casabaia][$category] $message');
}

class ErrorReporter {
  static ErrorSink sink = SentrySink();
  static bool isNetworkError(Object e) => e is SocketException || e is TimeoutException;
  static Future<void> report(Object e, StackTrace st, {String? where}) async {
    debugPrint('[Casabaia] ${where ?? 'inconnu'} : $e');
    try {
      if (isNetworkError(e)) {
        // Hors ligne = situation normale sur le terrain : simple trace, pas un bug.
        sink.breadcrumb('Réseau indisponible (${where ?? 'inconnu'})', category: 'network');
        return;
      }
      await sink.capture(e, st, tags: {'where': where ?? 'unknown'});
    } catch (_) {}
  }
  static void breadcrumb(String message, {String category = 'tour'}) {
    try { sink.breadcrumb(message, category: category); } catch (_) {}
  }
}

import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../config.dart';
import '../models/tour_session.dart';
import 'tour_controller.dart';

/// Chiffres du rapport, calculés à partir de la tournée.
class ReportData {
  final int collected, skipped;
  final Map<String, String> skippedReasons; // nom du point -> motif
  final double kmDone, minutes, fuelUsed, fuelSaved, moneySaved;
  final String date;

  ReportData._(this.collected, this.skipped, this.skippedReasons, this.kmDone,
      this.minutes, this.fuelUsed, this.fuelSaved, this.moneySaved, this.date);

  factory ReportData.from(TourSession s, TourController c) {
    // Tournée en cours : on compte aussi ce qui reste à faire (estimation).
    final km = (s.traveledMeters + (s.isFinished ? 0 : s.remainingMeters)) / 1000;
    final end = s.finishedAt ?? DateTime.now();
    final saved = SavingsEntry(s.classicMeters, s.optimizedMeters).savedKm / AppConfig.kmPerLiter;
    return ReportData._(
      s.collectedIds.length,
      s.skipped.length,
      s.skipped.map((id, r) => MapEntry(c.byId(id)?.name ?? id, r)),
      km,
      end.difference(s.startedAt).inSeconds / 60,
      km / AppConfig.kmPerLiter,
      saved,
      saved * AppConfig.pricePerLiter,
      TourController.dayKey(s.startedAt),
    );
  }

  /// Texte prêt à envoyer par WhatsApp.
  String toText() {
    final b = StringBuffer()
      ..writeln('*Rapport de tournée - $date*')
      ..writeln('Points collectés : $collected')
      ..writeln('Points ignorés : $skipped');
    skippedReasons.forEach((n, r) => b.writeln('  - $n : $r'));
    b
      ..writeln('Km parcourus : ${kmDone.toStringAsFixed(1)}')
      ..writeln('Temps total : ${minutes.round()} min')
      ..writeln('Essence consommée : ${fuelUsed.toStringAsFixed(1)} L')
      ..writeln('Essence économisée : ${fuelSaved.toStringAsFixed(2)} L '
          '(${moneySaved.toStringAsFixed(1)} MAD)');
    return b.toString();
  }
}

class ReportService {
  /// Partage le résumé en texte (WhatsApp apparaît dans la liste).
  static Future<void> shareText(ReportData d) => Share.share(d.toText());

  /// Génère un PDF et ouvre le menu de partage.
  /// (Le PDF utilise la police par défaut : texte en français sans accents
  /// exotiques. Pour l'arabe il faudrait embarquer une police arabe.)
  static Future<void> sharePdf(ReportData d) async {
    final doc = pw.Document();
    doc.addPage(pw.Page(
      build: (_) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Text('Rapport de tournee - ${d.date}',
            style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 16),
        ...d.toText().split('\n').where((l) => !l.startsWith('*')).map(
              (l) => pw.Text(l, style: const pw.TextStyle(fontSize: 14)),
            ),
      ]),
    ));
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/rapport_${d.date}.pdf');
    await file.writeAsBytes(await doc.save());
    await Share.shareXFiles([XFile(file.path)], text: 'Rapport de tournée ${d.date}');
  }
}

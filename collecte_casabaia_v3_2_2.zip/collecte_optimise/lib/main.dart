import 'package:flutter/material.dart';
import 'l10n/app_strings.dart';
import 'screens/map_screen.dart';
import 'services/tour_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await TourController.instance.init();
  runApp(const CollecteApp());
}

class CollecteApp extends StatelessWidget {
  const CollecteApp({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: TourController.instance,
    builder: (context, _) => MaterialApp(
      title: S.t('app_title'),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.green, useMaterial3: true),
      builder: (context, child) => Directionality(
        textDirection: S.isAr ? TextDirection.rtl : TextDirection.ltr,
        child: child!,
      ),
      home: const MapScreen(),
    ),
  );
}

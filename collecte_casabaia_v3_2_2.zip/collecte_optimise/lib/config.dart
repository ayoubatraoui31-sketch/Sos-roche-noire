/// Paramètres généraux de l'application (faciles à modifier).
class AppConfig {
  /// Dépôt : départ et retour du camion (à adapter).
  static const double depotLat = 33.5985;
  static const double depotLng = -7.5860;

  /// 1 litre d'essence = 10 km pour un camion de collecte.
  static const double kmPerLiter = 10;

  /// Prix d'un litre en dirhams.
  static const double pricePerLiter = 13;

  /// Centre de la carte (Casablanca, 4 quartiers).
  static const double mapLat = 33.5920;
  static const double mapLng = -7.5700;

  /// Recalculer localement la tournée tous les N points collectés.
  /// Aucun appel à Google Directions.
  static const int recalcEvery = 5;

  /// Paramètres métier V2.
  static const double urgentFillThreshold = 80;
  static const int maxServiceMinutesPerPoint = 60;
  static const String appVersionLabel = '3.2.0-casabaia-gratuite';

  static const List<String> sectors = ['Hay Adil', 'Belvédère', 'Roches Noires', 'Aïn Borja'];
  static const List<String> teamLeaders = ['Rachid Samsam', 'Goumni Mohamed', 'Bouchta', 'Soufiane'];
  static const List<String> vehicles = ['CAM-01', 'CAM-02', 'CAM-03', 'CAM-04'];
}

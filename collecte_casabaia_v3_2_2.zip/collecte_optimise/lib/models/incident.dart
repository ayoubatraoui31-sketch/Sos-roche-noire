class Incident {
  final String id;
  final String pointId;
  final String sector;
  final String type;
  final String description;
  final String photoPath;
  final double? lat;
  final double? lng;
  final DateTime createdAt;
  final String status;

  const Incident({
    required this.id,
    required this.pointId,
    required this.sector,
    required this.type,
    required this.description,
    required this.photoPath,
    required this.createdAt,
    this.lat,
    this.lng,
    this.status = 'ouvert',
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'pointId': pointId, 'sector': sector, 'type': type,
    'description': description, 'photoPath': photoPath,
    'lat': lat, 'lng': lng, 'createdAt': createdAt.toIso8601String(), 'status': status,
  };

  factory Incident.fromJson(Map<String, dynamic> j) => Incident(
    id: j['id'] ?? '', pointId: j['pointId'] ?? '', sector: j['sector'] ?? '',
    type: j['type'] ?? 'Autre', description: j['description'] ?? '',
    photoPath: j['photoPath'] ?? '', lat: (j['lat'] as num?)?.toDouble(),
    lng: (j['lng'] as num?)?.toDouble(),
    createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now(),
    status: j['status'] ?? 'ouvert',
  );
}

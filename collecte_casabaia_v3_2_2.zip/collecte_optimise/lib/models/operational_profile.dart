/// Profil opérationnel d’une tournée de collecte.
/// Prépare la V2 multi-secteurs / multi-équipes / multi-véhicules.
class OperationalProfile {
  final String sector;
  final String depotName;
  final String vehicleId;
  final String driverName;
  final String teamLeaderName;

  const OperationalProfile({
    required this.sector,
    required this.depotName,
    required this.vehicleId,
    required this.driverName,
    required this.teamLeaderName,
  });

  Map<String, dynamic> toJson() => {
        'sector': sector,
        'depotName': depotName,
        'vehicleId': vehicleId,
        'driverName': driverName,
        'teamLeaderName': teamLeaderName,
      };

  factory OperationalProfile.fromJson(Map<String, dynamic> json) => OperationalProfile(
        sector: json['sector'] ?? '',
        depotName: json['depotName'] ?? '',
        vehicleId: json['vehicleId'] ?? '',
        driverName: json['driverName'] ?? '',
        teamLeaderName: json['teamLeaderName'] ?? '',
      );
}

/// Une tournée en cours (ou terminée). Sauvegardée localement pour
/// fonctionner hors ligne : l'itinéraire est calculé au départ.
class TourSession {
  List<String> remainingIds; // points restants, dans l'ordre optimal
  List<int> legsMeters; // distance de chaque tronçon (restants + retour dépôt)
  List<int> legsSeconds; // durée de chaque tronçon
  String encodedPolyline; // tracé encodé de l'itinéraire restant
  final int classicMeters; // distance avec l'ordre fixe (sans optimisation)
  final int optimizedMeters; // distance optimisée calculée au départ
  final int optimizedSeconds;
  final int totalStops;
  int traveledMeters; // distance déjà parcourue
  final DateTime startedAt;
  DateTime? finishedAt;
  List<String> collectedIds;
  Map<String, String> skipped; // id du point -> motif
  String? lastPointId; // dernier point visité (origine du recalcul)

  TourSession({
    required this.remainingIds,
    required this.legsMeters,
    required this.legsSeconds,
    required this.encodedPolyline,
    required this.classicMeters,
    required this.optimizedMeters,
    required this.optimizedSeconds,
    required this.totalStops,
    required this.startedAt,
    this.traveledMeters = 0,
    this.finishedAt,
    List<String>? collectedIds,
    Map<String, String>? skipped,
    this.lastPointId,
  })  : collectedIds = collectedIds ?? [],
        skipped = skipped ?? {};

  bool get isFinished => finishedAt != null;
  int get remainingMeters => legsMeters.fold(0, (a, b) => a + b);
  int get remainingSeconds => legsSeconds.fold(0, (a, b) => a + b);

  Map<String, dynamic> toJson() => {
        'remainingIds': remainingIds,
        'legsMeters': legsMeters,
        'legsSeconds': legsSeconds,
        'encodedPolyline': encodedPolyline,
        'classicMeters': classicMeters,
        'optimizedMeters': optimizedMeters,
        'optimizedSeconds': optimizedSeconds,
        'totalStops': totalStops,
        'traveledMeters': traveledMeters,
        'startedAt': startedAt.toIso8601String(),
        'finishedAt': finishedAt?.toIso8601String(),
        'collectedIds': collectedIds,
        'skipped': skipped,
        'lastPointId': lastPointId,
      };

  factory TourSession.fromJson(Map<String, dynamic> j) => TourSession(
        remainingIds: List<String>.from(j['remainingIds']),
        legsMeters: List<int>.from(j['legsMeters']),
        legsSeconds: List<int>.from(j['legsSeconds']),
        encodedPolyline: j['encodedPolyline'],
        classicMeters: j['classicMeters'],
        optimizedMeters: j['optimizedMeters'],
        optimizedSeconds: j['optimizedSeconds'],
        totalStops: j['totalStops'],
        traveledMeters: j['traveledMeters'],
        startedAt: DateTime.parse(j['startedAt']),
        finishedAt:
            j['finishedAt'] == null ? null : DateTime.parse(j['finishedAt']),
        collectedIds: List<String>.from(j['collectedIds']),
        skipped: Map<String, String>.from(j['skipped']),
        lastPointId: j['lastPointId'],
      );
}

/// Économie d'une journée : comparaison classique vs optimisé.
class SavingsEntry {
  final int classicMeters;
  final int optimizedMeters;
  SavingsEntry(this.classicMeters, this.optimizedMeters);

  /// Km économisés (jamais négatif).
  double get savedKm {
    final v = (classicMeters - optimizedMeters) / 1000;
    return v < 0 ? 0 : v;
  }

  Map<String, dynamic> toJson() =>
      {'classic': classicMeters, 'optimized': optimizedMeters};
  factory SavingsEntry.fromJson(Map<String, dynamic> j) =>
      SavingsEntry(j['classic'], j['optimized']);
}

/// État d'un point de collecte.
/// toCollect = vert, collected = gris, priority = rouge, skipped = orange.
enum PointStatus { toCollect, collected, priority, skipped }

/// Un point de collecte (conteneur ou benne).
class CollectionPoint {
  final String id;
  final String name;
  final String neighborhood; // quartier
  final String address;
  final double lat;
  final double lng;
  /// Type de déchet : ordures ménagères, recyclables, verts, encombrants...
  final String wasteType;
  /// Niveau de remplissage estimé (0-100).
  final int fillLevel;
  /// Priorité opérationnelle (1 = normale, 2 = importante, 3 = urgente).
  final int priorityLevel;
  /// Temps moyen de collecte sur le point, en minutes.
  final int serviceMinutes;
  PointStatus status;
  bool inTodayTour; // le point fait-il partie de la tournée du jour ?

  CollectionPoint({
    required this.id,
    required this.name,
    required this.neighborhood,
    required this.address,
    required this.lat,
    required this.lng,
    this.wasteType = 'ordures_menageres',
    this.fillLevel = 0,
    this.priorityLevel = 1,
    this.serviceMinutes = 3,
    this.status = PointStatus.toCollect,
    this.inTodayTour = true,
  });

  // --- Conversion vers/depuis JSON (pour le stockage local) ---
  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'neighborhood': neighborhood,
        'address': address,
        'lat': lat,
        'lng': lng,
        'wasteType': wasteType,
        'fillLevel': fillLevel,
        'priorityLevel': priorityLevel,
        'serviceMinutes': serviceMinutes,
        'status': status.name,
        'inTodayTour': inTodayTour,
      };

  factory CollectionPoint.fromJson(Map<String, dynamic> j) => CollectionPoint(
        id: j['id'],
        name: j['name'],
        neighborhood: j['neighborhood'],
        address: j['address'],
        lat: (j['lat'] as num).toDouble(),
        lng: (j['lng'] as num).toDouble(),
        wasteType: j['wasteType'] ?? 'ordures_menageres',
        fillLevel: ((j['fillLevel'] ?? 0) as num).clamp(0, 100).toInt(),
        priorityLevel: ((j['priorityLevel'] ?? 1) as num).clamp(1, 3).toInt(),
        serviceMinutes: ((j['serviceMinutes'] ?? 3) as num).clamp(1, 60).toInt(),
        status: PointStatus.values.byName(j['status']),
        inTodayTour: j['inTodayTour'] ?? true,
      );
}

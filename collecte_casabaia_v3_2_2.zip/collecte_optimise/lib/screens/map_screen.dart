import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../config.dart';
import '../l10n/app_strings.dart';
import '../services/directions_service.dart';
import '../services/marker_icons.dart';
import '../services/tour_controller.dart';
import 'navigation_screen.dart';
import 'points_screen.dart';
import 'report_screen.dart';
import 'savings_screen.dart';
import 'supervisor_dashboard_screen.dart';
import 'incident_screen.dart';
import '../services/location_service.dart';
import '../widgets/app_map.dart';

/// Écran d'accueil : carte, marqueurs, itinéraire optimisé en bleu.
class MapScreen extends StatelessWidget {
  const MapScreen({super.key, this.controller});

  /// Contrôleur injecté (tests). Par défaut : celui de l'application.
  final TourController? controller;

  @override
  Widget build(BuildContext context) {
    final c = controller ?? TourController.instance;
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final s = c.session;

        final markers = c.points.map((p) => Marker(
              point: LatLng(p.lat, p.lng),
              width: 42,
              height: 42,
              child: MarkerIcons.of(p.status, opacity: p.inTodayTour ? 1 : 0.4),
            )).toList();

        final polylines = <Polyline>[];
        if (s != null && s.encodedPolyline.isNotEmpty) {
          polylines.add(Polyline(
            points: DirectionsService.decodePolyline(s.encodedPolyline),
            color: Colors.blue,
            strokeWidth: 5,
          ));
        }

        return Scaffold(
          appBar: AppBar(
            title: Text(S.t('app_title')),
            actions: [
              IconButton(icon: const Icon(Icons.list_alt), tooltip: S.t('my_tour'),
                  onPressed: () => _go(context, PointsScreen(controller: c))),
              IconButton(icon: const Icon(Icons.savings), tooltip: S.t('savings'),
                  onPressed: () => _go(context, SavingsScreen(controller: c))),
              IconButton(icon: const Icon(Icons.description), tooltip: S.t('report'),
                  onPressed: () => _go(context, ReportScreen(controller: c))),
              IconButton(icon: const Icon(Icons.dashboard), tooltip: 'Superviseur', onPressed: () => _go(context, SupervisorDashboardScreen(controller: c))),
              IconButton(icon: const Icon(Icons.warning_amber), tooltip: 'Incident', onPressed: () => _go(context, IncidentScreen(controller: c))),
              IconButton(icon: const Icon(Icons.my_location), tooltip: 'GPS véhicule', onPressed: () async { final pos = await LocationService().current(); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(pos == null ? 'GPS indisponible ou permission refusée' : 'GPS : ${pos.latitude.toStringAsFixed(6)}, ${pos.longitude.toStringAsFixed(6)}'))); }),
              IconButton(icon: const Icon(Icons.translate),
                  onPressed: () => c.setLang(S.isAr ? 'fr' : 'ar')),
            ],
          ),
          body: Stack(children: [
            AppMap(
              target: const LatLng(AppConfig.mapLat, AppConfig.mapLng),
              zoom: 13.5,
              markers: markers,
              polylines: polylines,
            ),
            Positioned(left: 8, top: 8, child: _legend()),
            Positioned(left: 0, right: 0, bottom: 0, child: _bottomPanel(context, c)),
          ]),
        );
      },
    );
  }

  void _go(BuildContext context, Widget screen) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => screen));

  /// Petite légende des couleurs.
  Widget _legend() => Card(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _dot(Colors.green, S.t('legend_green')),
            _dot(Colors.grey, S.t('legend_grey')),
            _dot(Colors.red, S.t('legend_red')),
          ]),
        ),
      );

  Widget _dot(Color c, String t) => Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.circle, size: 12, color: c),
        const SizedBox(width: 6),
        Text(t, style: const TextStyle(fontSize: 12)),
      ]);

  /// Panneau du bas : distance/durée + boutons d'action.
  Widget _bottomPanel(BuildContext context, TourController c) {
    final s = c.session;
    return Card(
      margin: const EdgeInsets.all(8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (c.error != null)
            Text('${S.t('error')} : ${c.error}',
                style: const TextStyle(color: Colors.red, fontSize: 12), maxLines: 3),
          if (s != null && !s.isFinished)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                '${S.t('distance')} : ${(s.remainingMeters / 1000).toStringAsFixed(1)} km   •   '
                '${S.t('duration')} : ${(s.remainingSeconds / 60).round()} min',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          if (c.loading)
            const LinearProgressIndicator()
          else if (s == null)
            FilledButton.icon(
                icon: const Icon(Icons.route),
                label: Text(S.t('compute')),
                onPressed: c.computeTour)
          else if (s.isFinished)
            FilledButton.icon(
                icon: const Icon(Icons.refresh),
                label: Text(S.t('new_day')),
                onPressed: c.startNewDay)
          else
            FilledButton.icon(
                icon: const Icon(Icons.navigation),
                label: Text(S.t('start_nav')),
                onPressed: () => _go(context, NavigationScreen(controller: c))),
        ]),
      ),
    );
  }
}

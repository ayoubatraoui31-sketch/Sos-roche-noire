import 'package:flutter/material.dart';
import '../config.dart';
import '../services/tour_controller.dart';
import '../models/collection_point.dart';
import 'report_screen.dart';

class SupervisorDashboardScreen extends StatelessWidget {
  const SupervisorDashboardScreen({super.key, this.controller});

  /// Contrôleur injecté (tests). Par défaut : celui de l'application.
  final TourController? controller;

  @override
  Widget build(BuildContext context) {
    final c = controller ?? TourController.instance;
    return ListenableBuilder(
      listenable: c,
      builder: (_, __) {
        final total = c.points.length;
        final collected = c.points.where((p) => p.status == PointStatus.collected).length;
        final skipped = c.points.where((p) => p.status == PointStatus.skipped).length;
        final urgent = c.points.where((p) => p.priorityLevel >= 3 || p.fillLevel >= 80).length;
        return Scaffold(
          appBar: AppBar(title: const Text('Tableau de bord superviseur')),
          body: RefreshIndicator(
            onRefresh: () async => c.refreshOperationalData(),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text('CASABAIA • SUIVI TERRAIN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                const SizedBox(height: 12),
                GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.5, children: [
                  _stat('Points', '$total', Icons.location_on),
                  _stat('Collectés', '$collected', Icons.check_circle),
                  _stat('Prioritaires', '$urgent', Icons.warning),
                  _stat('Ignorés', '$skipped', Icons.block),
                ]),
                const SizedBox(height: 16),
                const Text('Secteurs', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                for (final sector in AppConfig.sectors) _sectorCard(context, c, sector),
                const SizedBox(height: 16),
                const Text('Équipes terrain', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                for (var i = 0; i < AppConfig.teamLeaders.length; i++)
                  ListTile(leading: const CircleAvatar(child: Icon(Icons.groups)), title: Text(AppConfig.teamLeaders[i]), subtitle: Text('${AppConfig.sectors[i]} • ${AppConfig.vehicles[i]}')),
                const SizedBox(height: 12),
                FilledButton.icon(icon: const Icon(Icons.description), label: const Text('Rapport opérationnel'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReportScreen(controller: c)))),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _stat(String title, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon), const Spacer(), Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), Text(title)])));

  Widget _sectorCard(BuildContext context, TourController c, String sector) {
    final ps = c.points.where((p) => p.neighborhood == sector).toList();
    final done = ps.where((p) => p.status == PointStatus.collected).length;
    final percent = ps.isEmpty ? 0.0 : done / ps.length;
    return Card(child: ListTile(title: Text(sector), subtitle: Text('$done / ${ps.length} points collectés'), trailing: SizedBox(width: 90, child: LinearProgressIndicator(value: percent)), onTap: () => c.selectOnly(sector)));
  }
}

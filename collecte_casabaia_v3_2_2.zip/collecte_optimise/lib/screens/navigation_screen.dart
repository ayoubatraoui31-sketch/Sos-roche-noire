import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../l10n/app_strings.dart';
import '../services/directions_service.dart';
import '../services/marker_icons.dart';
import '../services/tour_controller.dart';
import '../widgets/app_map.dart';
import 'report_screen.dart';

/// Guidage étape par étape : un point à la fois.
class NavigationScreen extends StatelessWidget {
  const NavigationScreen({super.key, this.controller});

  /// Contrôleur injecté (tests). Par défaut : celui de l'application.
  final TourController? controller;

  @override
  Widget build(BuildContext context) {
    final c = controller ?? TourController.instance;
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final s = c.session;
        final stop = c.currentStop;

        // Tournée terminée (ou inexistante)
        if (s == null || stop == null) {
          return Scaffold(
            appBar: AppBar(title: Text(S.t('start_nav'))),
            body: Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text(s == null ? S.t('no_tour') : S.t('finished'),
                    style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 16),
                if (s != null)
                  FilledButton(
                    onPressed: () => Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (_) => ReportScreen(controller: c))),
                    child: Text(S.t('see_report')),
                  ),
              ]),
            ),
          );
        }

        final done = s.totalStops - s.remainingIds.length;
        final legKm = s.legsMeters.isEmpty ? 0.0 : s.legsMeters.first / 1000;

        return Scaffold(
          appBar: AppBar(title: Text('${S.t('current_stop')} ${done + 1}/${s.totalStops}')),
          body: Column(children: [
            // Mini-carte centrée sur le point actuel
            SizedBox(
              height: 260,
              child: AppMap(
                key: ValueKey(stop.id), // recrée la carte à chaque nouveau point
                target: LatLng(stop.lat, stop.lng),
                zoom: 15,
                markers: [Marker(point: LatLng(stop.lat, stop.lng), width: 44, height: 44, child: MarkerIcons.of(stop.status))],
                polylines: [Polyline(points: DirectionsService.decodePolyline(s.encodedPolyline), color: Colors.blue, strokeWidth: 5)],
              ),
            ),
            LinearProgressIndicator(value: done / s.totalStops, minHeight: 6),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(stop.name, style: Theme.of(context).textTheme.headlineSmall),
                  Text('${stop.neighborhood} • ${stop.address}'),
                  const SizedBox(height: 12),
                  Text('${S.t('to_next')} : ${legKm.toStringAsFixed(1)} km',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text('${S.t('remaining')} : ${(s.remainingMeters / 1000).toStringAsFixed(1)} km  •  '
                      '${(s.remainingSeconds / 60).round()} min'),
                  const Spacer(),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: FilledButton(
                      onPressed: () => c.completeCurrent(),
                      child: Text(S.t('collected_btn'), style: const TextStyle(fontSize: 18)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => _skipDialog(context, c),
                      child: Text(S.t('skip_btn')),
                    ),
                  ),
                ]),
              ),
            ),
          ]),
        );
      },
    );
  }

  /// Fenêtre de choix du motif.
  void _skipDialog(BuildContext context, TourController c) {
    final reasons = [
      S.t('reason_empty'),
      S.t('reason_inaccessible'),
      S.t('reason_blocked'),
      S.t('reason_other'),
    ];
    showDialog(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(S.t('skip_reason')),
        children: reasons
            .map((r) => SimpleDialogOption(
                  onPressed: () {
                    Navigator.pop(ctx);
                    c.completeCurrent(skipReason: r);
                  },
                  child: Text(r, style: const TextStyle(fontSize: 16)),
                ))
            .toList(),
      ),
    );
  }
}

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/incident.dart';
import '../services/location_service.dart';
import '../services/tour_controller.dart';

class IncidentScreen extends StatefulWidget {
  const IncidentScreen({super.key, this.controller});
  final TourController? controller;
  @override State<IncidentScreen> createState() => _IncidentScreenState();
}

class _IncidentScreenState extends State<IncidentScreen> {
  final description = TextEditingController();
  final picker = ImagePicker();
  String type = 'Benne pleine';
  String? photo;
  bool saving = false;

  Future<void> takePhoto() async {
    final x = await picker.pickImage(source: ImageSource.camera, imageQuality: 75, maxWidth: 1600);
    if (x != null) setState(() => photo = x.path);
  }

  Future<void> save() async {
    setState(() => saving = true);
    final c = widget.controller ?? TourController.instance;
    final pos = await LocationService().current();
    await c.addIncident(Incident(
      id: 'INC-${DateTime.now().millisecondsSinceEpoch}',
      pointId: c.currentStop?.id ?? '', sector: c.profile.sector, type: type,
      description: description.text.trim(), photoPath: photo ?? '',
      lat: pos?.latitude, lng: pos?.longitude,
      createdAt: DateTime.now(), // champ obligatoire : sans lui, l'app ne compile pas
    ));
    if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Incident enregistré'))); Navigator.pop(context); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Signaler un incident')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'Type'), items: ['Benne pleine','Obstacle','Dépôt sauvage','Véhicule bloquant','Déchet vert','Encombrants','Autre'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => type = v!)),
      const SizedBox(height: 12),
      TextField(controller: description, maxLines: 4, decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      if (photo != null) ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(photo!), height: 220, fit: BoxFit.cover)),
      OutlinedButton.icon(onPressed: takePhoto, icon: const Icon(Icons.camera_alt), label: Text(photo == null ? 'Prendre une photo' : 'Reprendre la photo')),
      const SizedBox(height: 12),
      Card(child: ListTile(leading: const Icon(Icons.location_on), title: const Text('GPS réel'), subtitle: Text('La position du véhicule sera enregistrée avec l’incident.'))),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save), label: Text(saving ? 'Enregistrement…' : 'Enregistrer l’incident')),
    ]),
  );
}

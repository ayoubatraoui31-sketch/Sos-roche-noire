import 'package:flutter/material.dart';
import '../config.dart';
import '../l10n/app_strings.dart';
import '../models/tour_session.dart';
import '../services/tour_controller.dart';

/// Compteur d'économies : classique vs optimisé, en km, litres et dirhams.
class SavingsScreen extends StatelessWidget {
  const SavingsScreen({super.key, this.controller});

  /// Contrôleur injecté (tests). Par défaut : celui de l'application.
  final TourController? controller;

  @override
  Widget build(BuildContext context) {
    final c = controller ?? TourController.instance;
    final now = DateTime.now();
    final today = c.savings[TourController.dayKey(now)];
    final monthPrefix = TourController.dayKey(now).substring(0, 7); // "2026-10"

    // Total du mois
    double monthKm = 0;
    c.savings.forEach((day, e) {
      if (day.startsWith(monthPrefix)) monthKm += e.savedKm;
    });

    return Scaffold(
      appBar: AppBar(title: Text(S.t('savings'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _section(S.t('today')),
        if (today == null)
          Text(S.t('no_tour'))
        else ...[
          _row(S.t('classic'), '${(today.classicMeters / 1000).toStringAsFixed(1)} km'),
          _row(S.t('optimized'), '${(today.optimizedMeters / 1000).toStringAsFixed(1)} km'),
          _summary(today.savedKm),
        ],
        const SizedBox(height: 24),
        _section(S.t('month')),
        _summary(monthKm),
        const SizedBox(height: 24),
        _section(S.t('history')),
        ...(c.savings.keys.toList()..sort((a, b) => b.compareTo(a))).map((day) {
          final e = c.savings[day]!;
          final l = e.savedKm / AppConfig.kmPerLiter;
          return ListTile(
            dense: true,
            title: Text(day),
            trailing: Text('${e.savedKm.toStringAsFixed(1)} km • '
                '${(l * AppConfig.pricePerLiter).toStringAsFixed(0)} MAD'),
          );
        }),
      ]),
    );
  }

  Widget _section(String t) => Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(t, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)));

  Widget _row(String a, String b) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a), Text(b)]));

  /// Km économisés -> litres -> dirhams
  Widget _summary(double km) {
    final liters = km / AppConfig.kmPerLiter;
    final mad = liters * AppConfig.pricePerLiter;
    return Card(
      color: Colors.green.shade50,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          _row(S.t('saved_km'), km.toStringAsFixed(1)),
          _row(S.t('saved_l'), liters.toStringAsFixed(2)),
          _row(S.t('saved_mad'), mad.toStringAsFixed(1)),
        ]),
      ),
    );
  }
}

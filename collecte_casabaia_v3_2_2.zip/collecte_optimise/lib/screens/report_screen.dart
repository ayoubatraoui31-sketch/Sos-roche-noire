import 'package:flutter/material.dart';
import '../l10n/app_strings.dart';
import '../services/error_reporter.dart';
import '../services/report_service.dart';
import '../services/tour_controller.dart';

/// Rapport pour le superviseur : PDF ou WhatsApp.
class ReportScreen extends StatelessWidget {
  const ReportScreen({super.key, this.controller});

  /// Contrôleur injecté (tests). Par défaut : celui de l'application.
  final TourController? controller;

  @override
  Widget build(BuildContext context) {
    final c = controller ?? TourController.instance;
    final s = c.session;
    return Scaffold(
      appBar: AppBar(title: Text(S.t('report'))),
      body: s == null
          ? Center(child: Text(S.t('no_tour')))
          : _content(context, c, ReportData.from(s, c)),
    );
  }

  /// Exécute un partage ; en cas d'échec : message à l'écran + rapport au SaaS.
  Future<void> _safe(BuildContext context, String where, Future<void> Function() action) async {
    try {
      await action();
    } catch (e, st) {
      await ErrorReporter.report(e, st, where: where);
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('${S.t('error')} : $e')));
      }
    }
  }

  Widget _content(BuildContext context, TourController c, ReportData d) {
    Widget row(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Text(a, style: const TextStyle(fontSize: 16)),
                       Text(b, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))]));

    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(d.date, style: const TextStyle(fontSize: 14, color: Colors.grey)),
      row(S.t('collected_n'), '${d.collected}'),
      row(S.t('skipped_n'), '${d.skipped}'),
      ...d.skippedReasons.entries.map((e) => Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Text('• ${e.key} : ${e.value}', style: const TextStyle(color: Colors.grey)))),
      const Divider(),
      row(S.t('km_done'), '${d.kmDone.toStringAsFixed(1)} km'),
      row(S.t('time_total'), '${d.minutes.round()} min'),
      row(S.t('fuel_used'), '${d.fuelUsed.toStringAsFixed(1)} L'),
      row(S.t('saved_l'), '${d.fuelSaved.toStringAsFixed(2)} L'),
      row(S.t('saved_mad'), '${d.moneySaved.toStringAsFixed(1)} MAD'),
      const SizedBox(height: 24),
      FilledButton.icon(
          icon: const Icon(Icons.picture_as_pdf),
          label: Text(S.t('share_pdf')),
          onPressed: () => _safe(context, 'sharePdf', () => ReportService.sharePdf(d))),
      const SizedBox(height: 8),
      OutlinedButton.icon(
          icon: const Icon(Icons.chat),
          label: Text(S.t('share_wa')),
          onPressed: () => _safe(context, 'shareText', () => ReportService.shareText(d))),
    ]);
  }
}

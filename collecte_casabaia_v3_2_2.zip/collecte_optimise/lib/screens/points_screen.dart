import 'package:flutter/material.dart';
import '../l10n/app_strings.dart';
import '../models/collection_point.dart';
import '../services/marker_icons.dart';
import '../services/tour_controller.dart';

/// Liste des points : cocher ceux de la tournée du jour, ajouter, supprimer.
class PointsScreen extends StatelessWidget {
  const PointsScreen({super.key, this.controller});

  /// Contrôleur injecté (tests). Par défaut : celui de l'application.
  final TourController? controller;

  @override
  Widget build(BuildContext context) {
    final c = controller ?? TourController.instance;
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
            title: Text('${S.t('my_tour')} (${c.tourPoints.length}/${c.points.length})'),
            actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.checklist),
            onSelected: (v) {
              if (v == 'all') c.selectOnly(null);
              else if (v == 'none') c.selectNone();
              else if (v == 'reload') c.reloadFromAsset();
              else c.selectOnly(v);
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'all', child: Text(S.t('select_all'))),
              PopupMenuItem(value: 'none', child: Text(S.t('select_none'))),
              for (final q in ['Belvédère', 'Roches Noires', 'Hay Adil', 'Aïn Borja'])
                PopupMenuItem(value: q, child: Text('${S.t('only')} $q')),
              PopupMenuItem(value: 'reload', child: Text(S.t('reload'))),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.sync),
            tooltip: S.t('sync'),
            onPressed: () async {
              await c.syncWithServer();
              if (context.mounted) {
                ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text(S.t('sync_msg'))));
              }
            },
          ),
        ]),
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.add),
          label: Text(S.t('add_point')),
          onPressed: () => _addDialog(context, c),
        ),
        body: ListView(
          padding: const EdgeInsets.only(bottom: 88),
          children: c.points.map((p) {
            return Dismissible(
              key: ValueKey(p.id),
              direction: DismissDirection.endToStart, // glisser pour supprimer
              background: Container(
                  color: Colors.red,
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 16),
                  child: const Icon(Icons.delete, color: Colors.white)),
              onDismissed: (_) => c.removePoint(p.id),
              child: ListTile(
                leading: Icon(Icons.circle, color: statusColor(p.status)),
                title: Text(p.name),
                subtitle: Text('${p.neighborhood} • ${p.address}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  // Marquer prioritaire (rouge) / remettre normal (vert)
                  IconButton(
                    icon: Icon(Icons.warning_amber,
                        color: p.status == PointStatus.priority ? Colors.red : Colors.grey),
                    tooltip: p.status == PointStatus.priority ? S.t('normal') : S.t('priority'),
                    onPressed: () => c.setStatus(
                        p, p.status == PointStatus.priority ? PointStatus.toCollect : PointStatus.priority),
                  ),
                  Checkbox(value: p.inTodayTour, onChanged: (_) => c.toggleInTour(p)),
                ]),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  /// Formulaire d'ajout d'un point.
  void _addDialog(BuildContext context, TourController c) {
    final name = TextEditingController();
    final address = TextEditingController();
    final lat = TextEditingController();
    final lng = TextEditingController();
    const quartiers = ['Belvédère', 'Roches Noires', 'Hay Adil', 'Aïn Borja'];
    String quartier = quartiers.first;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: Text(S.t('add_point')),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: InputDecoration(labelText: S.t('name'))),
              DropdownButtonFormField<String>(
                value: quartier,
                decoration: InputDecoration(labelText: S.t('neighborhood')),
                items: quartiers.map((q) => DropdownMenuItem(value: q, child: Text(q))).toList(),
                onChanged: (v) => setState(() => quartier = v!),
              ),
              TextField(controller: address, decoration: InputDecoration(labelText: S.t('address'))),
              TextField(
                  controller: lat,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                  decoration: InputDecoration(labelText: '${S.t('lat')} (33.59…)')),
              TextField(
                  controller: lng,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                  decoration: InputDecoration(labelText: '${S.t('lng')} (-7.57…)')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(S.t('cancel'))),
            FilledButton(
              onPressed: () {
                final la = double.tryParse(lat.text.replaceAll(',', '.'));
                final lo = double.tryParse(lng.text.replaceAll(',', '.'));
                if (name.text.trim().isEmpty || la == null || lo == null) return;
                c.addPoint(CollectionPoint(
                  id: 'p${DateTime.now().millisecondsSinceEpoch}',
                  name: name.text.trim(),
                  neighborhood: quartier,
                  address: address.text.trim(),
                  lat: la,
                  lng: lo,
                ));
                Navigator.pop(ctx);
              },
              child: Text(S.t('save')),
            ),
          ],
        ),
      ),
    );
  }
}

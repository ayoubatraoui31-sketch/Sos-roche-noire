# V3.2 finale gratuite

Version simplifiée pour usage terrain. Aucun compte Google Cloud, aucune clé API Google, Firebase ou serveur payant n'est requis.

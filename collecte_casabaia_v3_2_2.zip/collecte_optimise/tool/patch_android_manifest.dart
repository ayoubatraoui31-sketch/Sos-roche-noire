// Ajoute au manifeste Android généré par `flutter create` les permissions
// nécessaires : sans elles, l'APK release n'a NI Internet (tuiles de carte),
// NI GPS, NI caméra (photos d'incidents).
// Utilisation (après `flutter create`) :  dart run tool/patch_android_manifest.dart
import 'dart:io';

void main() {
  final f = File('android/app/src/main/AndroidManifest.xml');
  if (!f.existsSync()) {
    stderr.writeln('Manifeste introuvable : lancez d\'abord "flutter create --platforms=android ."');
    exit(1);
  }
  var s = f.readAsStringSync();
  const perms = ['INTERNET', 'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'CAMERA'];
  final missing = perms.where((p) => !s.contains('android.permission.$p"')).toList();
  if (missing.isNotEmpty) {
    if (!s.contains('<application')) {
      stderr.writeln('Balise <application> introuvable dans le manifeste.');
      exit(1);
    }
    final block = missing.map((p) => '    <uses-permission android:name="android.permission.$p"/>\n').join();
    s = s.replaceFirst('<application', '$block    <application');
  }
  s = s.replaceFirst('android:label="collecte_optimise"', 'android:label="Casabaia Collecte"');
  f.writeAsStringSync(s);
  stdout.writeln('Manifeste OK. Permissions ajoutées : ${missing.isEmpty ? "aucune (déjà présentes)" : missing.join(", ")}');
}

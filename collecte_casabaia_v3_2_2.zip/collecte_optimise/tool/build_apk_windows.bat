@echo off
setlocal
cd /d "%~dp0.."
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERREUR: Flutter n'est pas installe ou absent du PATH.
  pause
  exit /b 1
)
echo [1/6] Generation Android...
call flutter create --platforms=android --org ma.casabaia .
if errorlevel 1 goto fail
echo [2/6] Dependances...
call flutter pub get
if errorlevel 1 goto fail
echo [3/6] Permissions Internet / GPS / camera...
call dart run tool/patch_android_manifest.dart
if errorlevel 1 goto fail
echo [4/6] Tests (non bloquant)...
call flutter test
if errorlevel 1 echo AVERTISSEMENT: des tests echouent, voir ci-dessus.
echo [5/6] Analyse (non bloquant)...
call flutter analyze
if errorlevel 1 echo AVERTISSEMENT: l'analyse signale des points.
echo [6/6] Compilation APK...
call flutter build apk --release
if errorlevel 1 goto fail
echo.
echo APK creee ici:
echo build\app\outputs\flutter-apk\app-release.apk
pause
exit /b 0
:fail
echo.
echo La compilation a rencontre une erreur. Copiez le message affiche et envoyez-le moi.
pause
exit /b 1

#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
command -v flutter >/dev/null 2>&1 || { echo "Flutter absent du PATH."; exit 1; }
flutter create --platforms=android --org ma.casabaia .
flutter pub get
dart run tool/patch_android_manifest.dart   # permissions Internet / GPS / caméra
flutter test    || echo "AVERTISSEMENT : des tests échouent (voir ci-dessus)."
flutter analyze || echo "AVERTISSEMENT : l'analyse signale des points (non bloquant)."
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"

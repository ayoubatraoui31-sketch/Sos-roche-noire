# V3.2 finale — changements

- Suppression des anciennes instructions Google Maps/Directions.
- Tournée calculée localement avec GPS et distance géographique.
- Conservation d'OpenStreetMap pour la visualisation de la carte.
- Stockage local des points, sessions et incidents.
- Ajout d'un script Windows de compilation APK.
- Ajout d'un script macOS/Linux de compilation APK.
- Version affichée : 3.2.0-casabaia-gratuite.

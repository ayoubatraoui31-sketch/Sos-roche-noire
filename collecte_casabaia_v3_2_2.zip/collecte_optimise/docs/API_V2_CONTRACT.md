# Contrat API V2 — proposition

## Ressources
- `POST /auth/login`
- `GET /sectors`
- `GET /points?sectorId=...`
- `POST /tours`
- `PATCH /tours/{id}/points/{pointId}`
- `POST /incidents`
- `POST /sync/batch`
- `GET /vehicles`
- `GET /teams`

## Règle offline
Le mobile doit enregistrer chaque action localement avec un identifiant d’opération et une date UTC. À la reconnexion, les opérations sont envoyées par lot. Le serveur répond avec les opérations acceptées/refusées afin d’éviter les doublons.

## Sécurité
- HTTPS obligatoire ;
- jeton court + refresh token ;
- aucune clé Google Maps dans le dépôt Git ;
- permissions par rôle : chauffeur, contrôleur, chef d’équipe, superviseur, administrateur ;
- journalisation des modifications sensibles.
